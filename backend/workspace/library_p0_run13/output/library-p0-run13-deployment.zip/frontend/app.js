document.getElementById('loadBtn').addEventListener('click', async () => {
  const res = await fetch('/api/items');
  const data = await res.json();
  document.getElementById('output').textContent = JSON.stringify(data, null, 2);
});
